export class Final{
oberoikiFull!:string
ID991674132!:number
oberoikiEmail!:string
}