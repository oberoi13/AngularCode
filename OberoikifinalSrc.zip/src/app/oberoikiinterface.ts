export interface exam{
    directive:string
    code:string
    explanation:string
}